
<?php echo $__env->make('vendor.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php 
use App\Traits\Helper;  
$name[] = 'nisn';
$name[] = 'nama';
$name[] = 'tempat_lahir';
$name[] = 'tgl_lahir';
$name[] = 'jk';
$name[] = 'no_telp';
$name[] = 'id_kelas';
$name[] = 'alamat';
$name[] = 'foto';
?>

<section class="section">
    <div class="section-header">
    <h1><?php echo e($title); ?></h1>
    
    <?php echo e(Breadcrumbs::render('edit_siswa')); ?>

    </div>
    <div class="section-body">
        <div class="card card-primary">
            <div class="card-header">
            <small>Isikan dengan data yang sesuai</small>
            </div>
            <div class="card-body">
                <?php if(session('msg')): ?>
                    <div class="alert alert-danger"><?php echo e(session('msg')); ?></div>
                <?php endif; ?>
                <form action="<?php echo e($url); ?>" method="post" enctype="multipart/form-data">
                       <?php echo csrf_field(); ?>
                        <?php echo e($method != null ? $method : ''); ?>

                        <div class="row justify-content-center mb-4">
                            <div class="col">
                                <div class="image-live">
                                    <input type="file" class="d-none file-live" name="foto">
                                    <input type="file" class="d-none" value="<?php echo e(Helper::showData($data,$name[8])); ?>" name="foto-old">
                                    <img src="<?php echo e(asset('assets/img/avatar/avatar-5.png')); ?>"  style="width: 100px; height:100px" class="rounded-circle shadow mb-4 img-fluid" alt="" srcset="">
                                </div>
                                <div class="text-danger"><i>File Tidak Boleh Lebih besar dari 1Mb</i></div>
                            </div>
                        </div>
                        <div class="row">
                           <div class="form-group col-md-6">
                               <label for="exampleInputEmail1">NISN (Nomor Induk Siswa Nasional)</label>
                               <?php if(is_null($data)): ?>
                                    <input type="text" class="form-control <?php $__errorArgs = [$name[0]];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e($newNis); ?>" name="<?php echo e($name[0]); ?>" autocomplete="off"  />
                               <?php else: ?>
                                    <input type="text" class="form-control <?php $__errorArgs = [$name[0]];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(Helper::showData($data,$name[0])); ?>" name="<?php echo e($name[0]); ?>" autocomplete="off" />
                                <?php endif; ?>
                           </div>
                           <div class="form-group col-md-6">
                               <label for="exampleInputEmail1">Nama</label>
                               <input type="text" class="form-control <?php $__errorArgs = [$name[1]];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(Helper::showData($data,$name[1])); ?>" name="<?php echo e($name[1]); ?>" autocomplete="off" />
                           </div>
                           <div class="form-group col-md-6">
                               <label for="exampleInputEmail1">Tempat Lahir</label>
                               <input type="text" class="form-control <?php $__errorArgs = [$name[2]];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(Helper::showData($data,$name[2])); ?>" name="<?php echo e($name[2]); ?>" autocomplete="off" />
                           </div>
                           <div class="form-group col-md-6">
                               <label for="exampleInputEmail1">Tanggal Lahir</label>
                               <input type="date" class="form-control <?php $__errorArgs = [$name[3]];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(Helper::showData($data,$name[3])); ?>" name="<?php echo e($name[3]); ?>" autocomplete="off" />
                           </div>

                           <div class="form-group col-md-6">
                               <label for="exampleInputEmail1">Jenis Kelamin</label>
                               <select id="tipe" class="form-control <?php $__errorArgs = [$name[4]];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   name="<?php echo e($name[4]); ?>" autocomplete="off">
                                   <option value="" selected disabled> Pilih Jenis Kelamin</option>

                                   <option value="L" <?php echo e((old($name[4]) == "L") ? 'selected' : ''); ?>

                                       <?php echo e(Helper::showDataSelected2($data,$name[4],"L")); ?>>
                                       Laki - Laki
                                   </option>
                                   <option value="P" <?php echo e((old($name[4]) == "P") ? 'selected' : ''); ?>

                                       <?php echo e(Helper::showDataSelected2($data,$name[4],"P")); ?>>
                                       Perempuan
                                   </option>
                               </select>
                           </div>
                           <div class="form-group col-md-6">
                               <label for="exampleInputEmail1">No Telepon</label>
                               <input type="text" class="form-control phone-number <?php $__errorArgs = [$name[5]];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(Helper::showData($data,$name[5])); ?>" name="<?php echo e($name[5]); ?>" autocomplete="off" />
                           </div>
                           
                           <div class="form-group col-md-12">
                               <label for="exampleInputEmail1">Kelas</label>
                               <select id="kelas" class="form-control <?php $__errorArgs = [$name[6]];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   name="<?php echo e($name[6]); ?>" autocomplete="off">
                                   <option value="" selected disabled> Pilih Kelas</option>

                                   <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <option value="<?= $key->{$name[6]} ?>"
                                       <?php echo e((old($name[6]) == $key->{$name[6]}) ? 'selected' : ''); ?>

                                       <?php echo e(Helper::showDataSelected($data,$name[6],$key->{$name[6]})); ?>>
                                       <?php echo e($key->nama." ".$key->jurusan->nama); ?>

                                   </option>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                               </select>
                           </div>
                           <div class="form-group col-md-12">
                            <label for="exampleInputEmail1">Alamat</label>
                            <textarea type="text" class="form-control <?php $__errorArgs = [$name[7]];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="5"
                                rows="6" style="height:100px" value="" name="<?php echo e($name[7]); ?>"
                                autocomplete="off"><?php echo e(Helper::showData($data,$name[7])); ?></textarea>
                            </div>
                        </div>
                       
                       <input type="submit" class="btn btn-success" value="Simpan" />
                       <a href="" onclick="history.back()" class="btn btn-default">Kembali</a>
                   </form>
            </div>
        </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('vendor')); ?>/cleave.js/cleave.min.js"></script>
<script src="<?php echo e(asset('vendor')); ?>/cleave.js/addons/cleave-phone.id.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/image-live.js"></script>

<script>
    var cleavePN = new Cleave('.phone-number', {
        phone: true,
        phoneRegionCode: 'ID'
    });
    

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('app',['content'=>'user'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\administrasi\resources\views/pages/siswa/form.blade.php ENDPATH**/ ?>