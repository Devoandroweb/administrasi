
<?php echo $__env->make('vendor.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startPush('style'); ?>
<style>
     table{
        border-collapse: collapse;
        border: 1px solid black;
    }
    table th{
        text-transform: uppercase;
    }
    table th,td{
        padding: 0.2rem 0.5rem !important;
        border: 1px solid black !important;
        height: 30px !important;
    }
</style>
<?php $__env->stopPush(); ?>
<?php
    use App\Traits\Helper;

    function terbayar($terbayar,$idsiswa,$tipe)
    {
        $total = 0;
        foreach ($terbayar as $ter) {
            if($ter->id_siswa == $idsiswa){
                if($tipe == 1){ // biaya
                    $biaya = json_decode($ter->biaya);
                    foreach ($biaya as $biay) {
                        $total += (int)$biay->nominal;
                    }
                }elseif($tipe == 2){ // tunggakan
                    $tunggakan = json_decode($ter->tunggakan);
                    foreach ($tunggakan as $tgg) {
                        $total += (int)$tgg->nominal;
                    }
                }
            }
        }
        return [Helper::ribuan($total),$total];
    }
    function kurangAdm($administrasi,$idsiswa)
    {
        $total = 0;
        foreach ($administrasi as $adm) {
            if($adm->id_siswa == $idsiswa){
                $total += $adm->nominal;
            }
        }
        return  [Helper::ribuan($total),$total];
    }
    function kurangTgg($tunggakan,$idsiswa)
    {
        $total = 0;
        foreach ($tunggakan as $tgg) {
            if($idsiswa == $tgg->id_siswa){
                $total += $tgg->nominal;
            }
        }
        return  [Helper::ribuan($total),$total];
    }
    function cariKelas($kelas,$id)
    {
        if($id == 0){
            return 'ALUMNI';
        }else{
            foreach ($kelas as $key) {
                if($key->id_kelas == $id){
                    return $key->namaKelas();
                }
            }
        }
        return null;
    }
?>
<section class="section">
    <div class="section-header">
    <h1>Rekapitulasi</h1>
    
    <?php echo e(Breadcrumbs::render('kelas')); ?>

    </div>

    <div class="section-body">
        <div class="card card-primary">
            <div class="card-header">
            <h4>Rekapitulasi Administrasi Siswa per Siswa</h4>
            <div class="card-header-action">
                <a href="<?php echo e(url('export/rekap-per-siswa')); ?>" class="btn btn-success mr-2">
                <i class="fas fa-file-excel"></i> Export
                </a>
            </div>
            <div class="card-header-action dropdown ">
                <?php if(cariKelas($kelas,$k) != null): ?>
                <a href="#" data-toggle="dropdown" class="btn btn-danger filter-kelas dropdown-toggle mr-2" aria-expanded="false"><i class="fas fa-filter"></i> Filter : <?php echo e(cariKelas($kelas,$k)); ?></a>
                <?php else: ?>
                <a href="#" data-toggle="dropdown" class="btn btn-danger filter-kelas dropdown-toggle mr-2" aria-expanded="false"><i class="fas fa-filter"></i> Pilih Kelas</a>
                <?php endif; ?>
                <ul class="dropdown-menu dropdown-menu-sm dropdown-menu-right" x-placement="bottom-end" style="position: absolute; transform: translate3d(-126px, 31px, 0px); top: 0px; left: 0px; will-change: transform;">
                    <li class="dropdown-title">Pilih Kelas</li>
                    <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="#" class="dropdown-item kelas-item" data-text="<?php echo e($kel->namaKelas()); ?>" data-id="<?php echo e($kel->id_kelas); ?>"><?php echo e($kel->namaKelas()); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="#" class="dropdown-item kelas-item" data-text="Alumni" data-id="0">Alumni</a></li>
                </ul>
            </div>
            <form class="card-header-form" method="GET" action="<?php echo e(url('rekap/per-siswa')); ?>">
                <div class="input-group">
                <input type="hidden" name="k" class="id_kelas" value="<?php echo e($k); ?>">
                <input type="text" name="q" class="form-control mr-2" value="<?php echo e($q); ?>" placeholder="Cari NISN atau Nama">
                <div class="input-group-btn">
                    <button type="submit"  class="btn btn-primary btn-icon"><i class="fas fa-search"></i></button>
                </div>
                </div>
            </form>
            </div>
            <div class="card-body">
            <div class="loader-line form-loader d-none mb-2"></div>
            
            <div class="table-responsive">
               
                <table class="table" style="color: black">
                    <thead>
                        <tr class="text-center">
                            <th>No</th>
                            <th>NISN</th>
                            <th>Nama</th>
                            <th>Jenis</th>
                            <th>Terbayar</th>
                            <th>Kurang</th>
                            <th>Total Tanggungan</th>
                        </tr>
                    </thead>
                        <?php if(count($siswa) == 0): ?>
                            <tr><td colspan="7" class="text-danger text-center">Data tidak di temukan</td></tr>
                        <?php else: ?>
                            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td rowspan="2" class="text-center" width="3%"><?php echo e($loop->iteration); ?></td>
                                <td rowspan="2" ><?php echo e($s->nisn); ?></td>
                                <td rowspan="2"><?php echo e($s->nama); ?></td>
                                <td>Sekarang</td>
                                <td class="text-right"><?php echo e(terbayar($terbayar,$s->id_siswa,1)[0]); ?></td>
                                <td class="text-right"><?php echo e(kurangAdm($administrasi,$s->id_siswa)[0]); ?></td>
                                <td class="text-right"><?php echo e(Helper::ribuan(kurangAdm($administrasi,$s->id_siswa)[1] + terbayar($terbayar,$s->id_siswa,1)[1])); ?></td>
                            </tr>
                            <tr>
                                <td>Sebelumnya</td>
                                <td class="text-right"><?php echo e(terbayar($terbayar,$s->id_siswa,2)[0]); ?></td>
                                <td class="text-right"><?php echo e(kurangTgg($tunggakan,$s->id_siswa)[0]); ?></td>
                                <td class="text-right"><?php echo e(Helper::ribuan(terbayar($terbayar,$s->id_siswa,2)[1] + kurangTgg($tunggakan,$s->id_siswa)[1])); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    
                </table>
                
                <nav>
                <?php if(isset($_GET['q'])): ?>
                <?php
                    $params = array('q' => $_GET['q']);
                ?>
                <?php echo e($siswa->appends($params)->links('vendor.paginate')); ?>

                <?php else: ?>
                <?php echo e($siswa->links('vendor.paginate')); ?>

                <?php endif; ?>
                </nav>
            </div>
            </div>
        </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
    $(".kelas-item").click(function (e) { 
        e.preventDefault();
        $(".id_kelas").val($(this).data("id"));
        $(".filter-kelas").html("<i class='fas fa-filter'></i> Filter : "+$(this).data('text').toUpperCase());
    });
</script>
    
<?php $__env->stopPush(); ?>


<?php echo $__env->make('app',['content'=>'user'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\administrasi\resources\views/pages/rekap/per-siswa.blade.php ENDPATH**/ ?>