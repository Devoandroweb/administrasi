<?php use Illuminate\Support\Facades\Http; ?>
<div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar">
        <form class="form-inline mr-auto">
          <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
            <li class="">

            <a href="javascript:;" class="nav-link nav-link-lg d-md-flex align-items-center font-weight-bold">
              <span class="d-none d-md-block mr-1">Tahun Akademik : </span>
              <span class="d-md-none">TA : </span>
              
                <?php
                    echo Session::get('tahun_awal')." - ".Session::get('tahun_akhir');
                ?>
              
            </a>
          </li>
          </ul>
        </form>
        <ul class="navbar-nav navbar-right">
          
          <?php if(auth()->guard('web')->check()): ?>
          <?php if(auth()->guard('web')->user()->role != 3): ?>
          <li class="nav-item active">
            <a href="<?php echo e(url('pembayaran')); ?>" class="nav-link nav-link-lg d-flex align-items-center">
              <span class="btn btn-warning rounded-pill">
                <i class="fas fa-hand-holding-usd" style="font-size: 13px"></i>  
                   Pembayaran Siswa
                </span>
            </a>
          </li>
          
          <li class="nav-item active">
            <a href="<?php echo e(url('whatsapp')); ?>" class="nav-link nav-link-lg d-flex align-items-center">
              <?php 
                
                $res = null;
                try {
                  $res = Http::get("http://localhost:8989/check-auth")->throw()->json();
                } catch (\Throwable $th) {
                  $activeWa = 'bg-danger';
                }
                if($res != null){
                    $activeWa = 'bg-success';
                }else{
                    $activeWa = 'bg-danger';
                }
              ?>
              <span class="dot <?php echo e($activeWa); ?> mr-2 status-wa"></span> Whatsapp Gateway
            </a>
          </li>
          <?php endif; ?>
          <?php endif; ?>
          <li class="dropdown"><a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
            <img alt="image" src="<?php echo e(asset('assets')); ?>/img/avatar/default.png" class="rounded-circle mr-1">
            <?php if(Auth::guard('web')->check()): ?>
            <div class="d-sm-none d-lg-inline-block">Hi, <?php echo e(Auth::user()->name); ?></div></a>
            <?php endif; ?>
            <?php if(Auth::guard('siswa')->check()): ?>
            <div class="d-sm-none d-lg-inline-block">Hi, <?php echo e(Auth::guard('siswa')->user()->nama); ?></div></a>
            <?php endif; ?>
            <div class="dropdown-menu dropdown-menu-right">
              <div class="dropdown-title">Logged in 5 min ago</div>
              <?php if(auth()->guard('web')->check()): ?>
              
              <a href="<?php echo e(url('reset-administrasi')); ?>" id="reset_adm" class="dropdown-item has-icon">
                <i class="fas fa-redo"></i> Calculate Administrasi
              </a>
              <div class="dropdown-divider"></div>
              <a href="<?php echo e(route('logout')); ?>" class="dropdown-item has-icon text-danger">
                <i class="fas fa-sign-out-alt"></i> Logout
              </a>
              <?php endif; ?>

              <?php if(auth()->guard('siswa')->check()): ?>
              <a href="<?php echo e(route('logout-siswa')); ?>" class="dropdown-item has-icon text-danger">
                <i class="fas fa-sign-out-alt"></i> Logout
              </a>
              <?php endif; ?>
            </div>
          </li>
        </ul>
      </nav><?php /**PATH D:\xampp\htdocs\administrasi\resources\views/panels/navbar.blade.php ENDPATH**/ ?>