<?php $__env->startPush('style-library'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendor')); ?>/datatables-net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('vendor')); ?>/datatables-net-select-bs4/css/select.bootstrap4.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js-library'); ?>
    <script src="<?php echo e(asset('vendor')); ?>/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('vendor')); ?>/datatables-net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo e(asset('vendor')); ?>/datatables-net-select-bs4/js/select.bootstrap4.min.js"></script>
<?php $__env->stopPush(); ?><?php /**PATH D:\xampp\htdocs\administrasi\resources\views/vendor/datatable.blade.php ENDPATH**/ ?>