<table>
    <thead>
    <tr style="font-weight: bold">
        <th style="font-weight: bold; background:rosybrown">NISN</th>
        <th style="font-weight: bold; background:rosybrown;">Nama</th>
        <th style="font-weight: bold; background:rosybrown;">Kelas</th>
        <?php $__currentLoopData = $ajarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ajaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <th colspan="2" style="font-weight: bold;text-align:center; background:aquamarine;"><?php echo e($ajaran['tahun_awal']."/".$ajaran['tahun_akhir']); ?></th>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
    </thead>
    <tbody>
    <?php $ajaranSession = Session::get('tahun_awal')." - ".Session::get('tahun_akhir'); ?>
    <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($siswa->admSiswa) != 0 || count($siswa->tunggakan) != 0): ?>
        <tr >
            <td style="background:darkkhaki"><?php echo e($siswa->nisn); ?></td>
            <td style="background:darkkhaki"><?php echo e($siswa->nama); ?></td>
            <td style="background:darkkhaki"><?php echo e($siswa->namaKelas()); ?></td>
            <?php $__currentLoopData = $ajarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ajaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td style="text-align:center;background:salmon;"><i>Biaya</i></td>
            <td style="text-align:center;background:salmon;"><i>Nominal</i></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <?php endif; ?>
        <?php $no = 1; $adm = ""; ?>
        
        <?php $__currentLoopData = $ajarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ajaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $textAjaran = $ajaran['tahun_awal']." - ".$ajaran['tahun_akhir'];
        foreach ($siswa->admSiswa as $adm_siswa) {
            if($ajaranSession == $textAjaran){
                // dd($adm_siswa->jenisAdministrasi);
                $adm .= "<tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>".$adm_siswa->jenisAdministrasi->nama."</td>
                    <td>".$adm_siswa->nominal."</td>@C".$no."
                </tr>";
                // $no++;
            }
            $no++;
        }

        $noa = 1;
        $data = $siswa->tunggakan;
        foreach ($siswa->tunggakan as $tgg_siswa) {
            if($textAjaran == $tgg_siswa->ajaran){
                $tTunggakan = "<td>".$tgg_siswa->nama_tunggakan."</td><td>".$tgg_siswa->nominal."</td>";
                $adm = str_replace("@C".$noa,$tTunggakan,$adm);
            }
            $noa++;
        }

        ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?= $adm ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php /**PATH D:\xampp\htdocs\administrasi\resources\views/pages/report/report-administrasi-siswa.blade.php ENDPATH**/ ?>