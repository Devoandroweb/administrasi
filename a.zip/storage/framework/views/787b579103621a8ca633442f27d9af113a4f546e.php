<!-- Main Content -->
      <div class="main-content">
        <?php echo $__env->yieldContent('content'); ?>
      </div><?php /**PATH D:\xampp\htdocs\administrasi\resources\views/panels/content.blade.php ENDPATH**/ ?>