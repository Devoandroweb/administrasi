<?php 
    $_TAHUN = date('Y'); 
?>
<form action="" id="form-data">
    <div class="form-group">
        <label>Tahun Ajaran Dari</label>
        <select id="tahun_awal" class="form-control "
            name="tahun_awal" autocomplete="off">
            <option value="" selected disabled> Pilih Tahun</option>
            <?php for($i = intval($_TAHUN); $i > 1999 ; $i--): ?>
            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
            <?php endfor; ?>
        </select>
    </div>
    <div class="form-group">
        <label>Tahun Ajaran Sampai</label>
        <select id="tahun_akhir" class="form-control "
            name="tahun_akhir" autocomplete="off">
            <option value="" selected disabled> Pilih Tahun</option>
            <?php for($i = intval($_TAHUN); $i > 1999 ; $i--): ?>
            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
            <?php endfor; ?>
        </select>
    </div>
</form>
<?php /**PATH D:\xampp\htdocs\administrasi\resources\views/pages/ajaran/form.blade.php ENDPATH**/ ?>