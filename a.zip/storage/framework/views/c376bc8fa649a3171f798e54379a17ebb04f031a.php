
<?php echo $__env->make('vendor.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<?php 
use App\Traits\Helper;
?>
<?php echo $__env->make('pages.siswa.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="section">
    <div class="section-header">
    <h1>Data Siswa</h1>
    
    <?php echo e(Breadcrumbs::render('siswa')); ?>

    </div>

    <div class="section-body">
        <div class="card card-primary">
            <div class="card-header">
            <h4>Data Siswa untuk mengelola Administrasi</h4>
            <?php if(auth()->guard('web')->user()->role == 3): ?>
            <div class="card-header-action">
                <a href="<?php echo e(url('export/siswa')); ?>" class="btn btn-success mr-2">
                <i class="fas fa-file-excel"></i> Export Siswa
                </a>
            </div>
            <?php endif; ?>
            <?php if(auth()->guard('web')->user()->role != 3): ?>
            <div class="card-header-action">
                <a href="<?php echo e($url); ?>" class="btn btn-primary mr-2" id="btn-add-data">
                <i class="fas fa-plus-circle"></i> Tambah Siswa
                </a>
            </div>
            <div class="card-header-action dropdown mr-2">
                <a href="#" data-toggle="dropdown" class="btn btn-success dropdown-toggle" aria-expanded="false"><i class="fas fa-file-excel"></i> Import/Export</a>
                <ul class="dropdown-menu dropdown-menu-sm dropdown-menu-right" x-placement="bottom-end" style="position: absolute; transform: translate3d(-126px, 31px, 0px); top: 0px; left: 0px; will-change: transform;">
                    <li class="dropdown-title">Pilih Menu</li>
                    <li><a href="<?php echo e(url('export/siswa')); ?>" class="dropdown-item">Export</a></li>
                    <li><a href="<?php echo e(url('siswa-import')); ?>" class="dropdown-item">Import</a></li>
                </ul>
            </div>
            <?php endif; ?>
            <div class="card-header-action dropdown  mr-2">
                <a href="#" data-toggle="dropdown" class="btn btn-danger filter dropdown-toggle" aria-expanded="false"><i class="fas fa-filter"></i> Status : Aktif</a>
                <ul class="dropdown-menu dropdown-menu-sm dropdown-menu-right" x-placement="bottom-end" style="position: absolute; transform: translate3d(-126px, 31px, 0px); top: 0px; left: 0px; will-change: transform;">
                    <li class="dropdown-title">Pilih Status</li>
                    <li><a href="<?php echo e(url("datatable/siswa-aktif")); ?>" data-text="aktif" class="dropdown-item sub-filter">Aktif</a></li>
                    <li><a href="<?php echo e(url("datatable/siswa-nonaktif")); ?>" data-text="non aktif" class="dropdown-item sub-filter">Non Aktif</a></li>
                </ul>
            </div>
            
            </div>
            <div class="card-body">
            <?php if(session('msg')): ?>
                <div class="alert alert-danger"><?php echo e(session('msg')); ?></div>
            <?php endif; ?>
            <div class="table-responsive">
                <table id="data" class="table table-striped" width="100%">
                <thead>
                    <tr>
                    <th class="text-center">
                        #
                    </th>
                    <th>NISN</th>
                    <th>Nama</th>
                    <th>Jenis Kelamin</th>
                    <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    
                </tbody>
                </table>
            </div>
            </div>
        </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>


<script>
    var _URL_DATATABLE = '<?php echo e(url("datatable/siswa-aktif")); ?>';
    
    setDataTable();
    function setDataTable() {
        $('#data').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: _URL_DATATABLE,
            },
            responsive: true,
            columns: [{
                    "data": 'DT_RowIndex',
                    orderable: false,
                    searchable: false,
                    width: '4%',
                    className: 'text-center'
                },{
                    data: 'nisn',
                    name: 'nisn',
                },{
                    data: 'nama',
                    name: 'nama',
                },{
                    data: 'jk',
                    name: 'jk',
                    searchable: false,
                },{
                    data: 'action',
                    name: 'action',
                    orderable: false,
                    searchable: false
                }]
        });
    }
    //DOM
    $(".sub-filter").click(function (e) { 
        e.preventDefault();
        _URL_DATATABLE = $(this).attr('href');
        $('#data').DataTable().destroy();
        setDataTable();
        $(".filter").text("Filter : "+capitalize($(this).data('text')));
    });
    

    //modal
    // open modal
    $(document).on("click",".detail", function (e) {
        
        e.preventDefault();
        $.ajax({
            type: "get",
            url: $(this).attr('href'),
            dataType: "JSON",
            success: function (response) {
                var data = response.data;
                $(".d-nama").text(data.nama);
                $(".d-nisn").text(data.nisn);
                $(".d-tmp-lhr").text(data.tempat_lahir);
                $(".d-tgl-lhr").text(data.tgl_lhr);
                $(".d-jk").text(data.jk_text);
                $(".d-telp").text(data.no_telp);
                var kelas = "";
                if(data.id_kelas != 0){
                    $(".d-kelas").text(data.kelas.nama+' '+data.kelas.jurusan.nama);
                }else{
                    $(".d-kelas").text('Alumni');
                }
                $(".d-alamat").text(data.alamat);
                $("#modal-detail").modal('show');
            }
        });
    });
$(document).on('click','.delete',function(e){
        e.preventDefault();
        Swal.fire({
            title: 'Kamu Yakin?',
            text: "Menghapus data ini akan menghapus semua data Administrasi yang di miliki oleh data ini",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya',
            cancelButtonText: 'Tidak'
            }).then((result) => {
            if (result.isConfirmed) {
                deleteData($(this).attr('href'),'post',{_method:'delete'});
            }
        })
    
});
function deleteData(url,type = "get",method = null){
    $.ajax({
        type: type,
        url: url,
        data : method,
        dataType: "JSON",
        success: function (response) {
            if(response.status){
                iziToast.success({
                    title: 'Success',
                    message: response.msg,
                    position: 'topRight'
                });
                $('#data').DataTable().destroy();
                setDataTable();
            }
        }
    });
}
$( document ).ajaxStart(function() {
    loadingLine(true);
});
$( document ).ajaxComplete(function() {
    loadingLine();
});
</script>

<?php $__env->stopPush(); ?>


<?php echo $__env->make('app',['content'=>'user'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\administrasi\resources\views/pages/siswa/index.blade.php ENDPATH**/ ?>