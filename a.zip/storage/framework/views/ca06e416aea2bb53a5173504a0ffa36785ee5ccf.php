<form action="" id="form-data">
    <div class="form-group">
        <label>Nama Jurusan</label>
        <input type="text" name="nama" class="form-control" required="" autocomplete="off">
    </div>
</form>
<?php /**PATH D:\xampp\htdocs\administrasi\resources\views/pages/jurusan/form.blade.php ENDPATH**/ ?>