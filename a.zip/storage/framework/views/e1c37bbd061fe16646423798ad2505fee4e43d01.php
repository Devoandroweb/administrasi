
<?php echo $__env->make('vendor.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startPush('style'); ?>
<style>
     table{
        border-collapse: collapse;
        border: 1px solid black;
    }
    table th{
        text-transform: uppercase;
    }
    table th,td{
        padding: 0.2rem 0.5rem !important;
        border: 1px solid black;
        height: 30px !important;

    }
</style>
<?php $__env->stopPush(); ?>
<section class="section">
    <div class="section-header">
    <h1>Rekapitulasi</h1>
    
    <?php echo e(Breadcrumbs::render('kelas')); ?>

    </div>

    <div class="section-body">
        <div class="card card-primary">
            <div class="card-header">
            <h4>Rekapitulasi Administrasi Siswa per Kelas</h4>
            
            </div>
            <div class="card-body">
            <div class="loader-line form-loader d-none mb-2"></div>
            <div class="table-responsive">
               
                <?php
                    use App\Models\MJenisAdministrasi;
                    use App\Models\MKelas;
                    use App\Models\MRekap;
                    use App\Traits\Helper;
                    $mJenisAdm = MJenisAdministrasi::paginate(10);
                    $mKelas = MKelas::with('jurusan')->orderBy('no_urut','asc')->get();
                    function cariRekap($_idJenisAdm,$_idKelas)
                    {
                        $mRekap = MRekap::all();
                        foreach ($mRekap as $key) {
                            if($key->id_jenis_administrasi == $_idJenisAdm && $key->id_kelas == $_idKelas){
                                return $key->total;
                            }
                        }
                        return 0;
                    }
                    function cariAdmTotal($id_jenis_adm,$id_kelas)
                    {
                        $data = DB::selectOne("SELECT m_siswa.id_kelas, SUM(administrasi.nominal) as nominal_adm FROM administrasi 
                                    INNER JOIN m_siswa ON m_siswa.id_siswa = administrasi.id_siswa 
                                    INNER JOIN m_kelas ON m_siswa.id_kelas = m_kelas.id_kelas 
                                    WHERE id_jenis_administrasi = {$id_jenis_adm} AND m_siswa.id_kelas = {$id_kelas} GROUP BY m_siswa.id_kelas");
                        if($data == null){
                            return 0;
                        }
                        return $data->nominal_adm;
                    }
                ?>
                <table id="data" class="table" style="color:black;" width="100%">
                    <thead>
                    <tr style="">
                        <th  rowspan="2" style="width:150px;vertical-align: center;text-align:center;border: 1px solid black;"><b>Nama Pembayaran</b> </th>
                        <th  rowspan="2" style="vertical-align: center;text-align:center;border: 1px solid black;"><b>Jenis</b> </th>
                        <th  colspan="<?php echo e($mKelas->count()); ?>" style="text-align:center;border: 1px solid black;"><b>Kelas</b></th>
                        <th style="width:100px;vertical-align: center;text-align:center;border: 1px solid black;" rowspan="2"><b>Jumlah</b></th>
                    </tr>
                    <tr style="">
                        <?php $__currentLoopData = $mKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th style="width:90px;font-weight:bold;text-align:center;border: 1px solid black;"><?php echo e($item->nama." ".$item->jurusan->nama); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    </thead>
                    <tbody>
                        <?php
                            $totalInKelasTanggungan = [];
                            $totalInKelasKurang = [];
                            $totalInKelasTerbayar = [];
                            foreach ($mKelas as $key) {
                                $totalInKelasTanggungan[strtolower($key->nama."_".$key->jurusan->nama)] = 0; 
                                $totalInKelasKurang[strtolower($key->nama."_".$key->jurusan->nama)] = 0; 
                                $totalInKelasTerbayar[strtolower($key->nama."_".$key->jurusan->nama)] = 0; 
                            }
                            
                        ?>
                        <?php $__currentLoopData = $mJenisAdm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenisAdm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <td rowspan="3" style="vertical-align: center;border: 1px solid black;"><?php echo e($jenisAdm->nama); ?></td>
                                <td style="border: 1px solid black;">Tanggungan</td>
                                <?php
                                    $totalTanggungan = 0;
                                ?> 
                                <?php $__currentLoopData = $mKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $nominalTanggungan = cariAdmTotal($jenisAdm->id,$item->id_kelas) + cariRekap($jenisAdm->id,$item->id_kelas);
                                        $totalTanggungan = $totalTanggungan + $nominalTanggungan;
                                        $totalInKelasTanggungan[strtolower($item->nama."_".$item->jurusan->nama)] = $totalInKelasTanggungan[strtolower($item->nama."_".$item->jurusan->nama)] + $nominalTanggungan;
                                        
                                    ?>
                                    <td style="text-align: right;border: 1px solid black;"><?php echo e(Helper::ribuan($nominalTanggungan)); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td style="text-align: right;border: 1px solid black;"><?php echo e(Helper::ribuan($totalTanggungan)); ?></td>
                            </tr>
                            
                            <tr>
                                <?php
                                    $totalTerbayar = 0;
                                ?>
                                <td style="border: 1px solid black;">Terbayar</td>
                                <?php $__currentLoopData = $mKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $nominalTerbayar = cariRekap($jenisAdm->id,$item->id_kelas);
                                        $totalTerbayar = $totalTerbayar + $nominalTerbayar;
                                        $totalInKelasTerbayar[strtolower($item->nama."_".$item->jurusan->nama)] = $totalInKelasTerbayar[strtolower($item->nama."_".$item->jurusan->nama)] + $nominalTerbayar;
                                    ?>
                                    <td style="text-align: right;border: 1px solid black;"><?php echo e(Helper::ribuan($nominalTerbayar)); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td style="text-align: right;border: 1px solid black;"><?php echo e(Helper::ribuan($totalTerbayar)); ?></td>
                            </tr>
                            
                            <tr>
                                <?php
                                    $totalKurang = 0;
                                ?>
                                <td style="border: 1px solid black;">Kurang</td>
                                <?php $__currentLoopData = $mKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $nominalKurang = cariAdmTotal($jenisAdm->id,$item->id_kelas);
                                        $totalKurang = $totalKurang + $nominalKurang;
                                        $totalInKelasKurang[strtolower($item->nama."_".$item->jurusan->nama)] = $totalInKelasKurang[strtolower($item->nama."_".$item->jurusan->nama)] + $nominalKurang;
                                    ?>
                                    <td style="text-align: right;border: 1px solid black;"><?php echo e(Helper::ribuan($nominalKurang)); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td style="text-align: right;border: 1px solid black;"><?php echo e(Helper::ribuan($totalKurang)); ?></td>
                            </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $jumlahInKelasTanggungan = 0;
                            $jumlahInKelasKurang = 0;
                            $jumlahInKelasTerbayar = 0;

                        ?>
                        <tr style="font-weight: bold;">
                            <td rowspan="3" style="vertical-align: center;border: 1px solid black;"><b>Total</b></td>
                            <td style="border: 1px solid black;"><b>Tanggungan</b></td>
                            <?php $__currentLoopData = $mKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $jumlah = $totalInKelasTanggungan[strtolower($kelas->nama."_".$kelas->jurusan->nama)];
                                $jumlahInKelasTanggungan = $jumlahInKelasTanggungan + $jumlah;
                            ?>
                                <td style="text-align: right;font-weight: bold;border: 1px solid black;"><?php echo e(Helper::ribuan($jumlah)); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td style="text-align: right;font-weight: bold;border: 1px solid black;"><?php echo e(Helper::ribuan($jumlahInKelasTanggungan)); ?></td>
                        </tr>
                        
                        <tr>
                            <td style="border: 1px solid black;"><b>Terbayar</b></td>
                            <?php $__currentLoopData = $mKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $jumlah = $totalInKelasTerbayar[strtolower($kelas->nama."_".$kelas->jurusan->nama)];
                                $jumlahInKelasTerbayar = $jumlahInKelasTerbayar + $jumlah;
                            ?>
                                <td style="text-align: right;font-weight: bold;border: 1px solid black;"><?php echo e(Helper::ribuan($jumlah)); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td style="text-align: right;font-weight: bold;border: 1px solid black;"><?php echo e(Helper::ribuan($jumlahInKelasTerbayar)); ?></td>

                        </tr>
                        <tr>
                            <td style="border: 1px solid black;"><b>Kurang</b></td>
                            <?php $__currentLoopData = $mKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $jumlah = $totalInKelasKurang[strtolower($kelas->nama."_".$kelas->jurusan->nama)];
                                $jumlahInKelasKurang = $jumlahInKelasKurang + $jumlah;
                            ?>
                                <td style="text-align: right;font-weight: bold;border: 1px solid black;"><?php echo e(Helper::ribuan($jumlah)); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td style="text-align: right;font-weight: bold;border: 1px solid black;"><?php echo e(Helper::ribuan($jumlahInKelasKurang)); ?></td>

                        </tr>
                    </tbody>
                </table>
            
            <?php echo e($mJenisAdm->links('vendor.paginate')); ?>


            </div>
            </div>
        </div>
</section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app',['content'=>'user'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\administrasi\resources\views/pages/rekap/per-kelas.blade.php ENDPATH**/ ?>