
<?php echo $__env->make('vendor.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<?php 
use App\Traits\Helper;
?>
<section class="section">
    <div class="section-header">
    <h1>Kelola Pemasukan</h1>
    
    <?php echo e(Breadcrumbs::render('pemasukan')); ?>

    </div>

    <div class="section-body">
        <div class="card card-primary">
            <div class="card-header">
            <h4>Data Pemasukan dari Siswa maupuan lainnya</h4>
            <div class="card-header-action">
                <a href="#" class="btn btn-danger btn-add-data" id="">
                Tambah Pengeluaran
                </a>
                <a href="#" class="btn btn-primary btn-add-data" id="">
                Tambah Pemasukan
                </a>
            </div>
            </div>
            <div class="card-body">
            <div class="table-responsive">
                <table id="data" class="table table-striped" width="100%">
                <thead>
                    <tr>
                    <th></th>
                    <th class="text-center">
                        #
                    </th>
                    <th>NIS</th>
                    <th>Nama</th>
                    <th>Detail</th>
                    <th>Total</th>
                    <th>Saldo</th>
                    <th></th>
                    
                    </tr>
                </thead>
                <tbody>
                    
                </tbody>
                </table>
            </div>
            </div>
        </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script type="text/javascript" src="<?php echo e(asset('vendor/autonumeric/autoNumeric.js')); ?>"></script>
<script>
// CUKUP UBAH VARIABLE BERIKUT
var _URL_INSERT = '<?php echo e(url("pemasukan/save")); ?>';
var _URL_DATATABLE = '<?php echo e(url("datatable/pemasukan")); ?>';
var _TABLE = null;
// SESUAIKAN COLUMN DATATABLE
// SESUAIKAN FIELD EDIT MODAL
setDataTable();
// setNumeric();
function setDataTable() {
    _TABLE = $('#data').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: _URL_DATATABLE,
        },
        rowReorder: {
            selector: 'td:nth-child(1)'
        },
        responsive: true,
        columns: [
            {
                className: 'dt-control dtr-control',
                data:null,
                width: '4%',
                orderable: false,
                searchable: false,
                defaultContent: ''},
            {
                "data": 'DT_RowIndex',
                orderable: false,
                searchable: false,
                width: '4%',
                className: 'text-center'
            },{
                data: 'nis',
                name: 'nis',
                orderable: false,
                width: '15%',

            },{
                data: 'nama',
                name: 'nama',
            },{
                data: 'detail',
                name: 'detail',
                visible: false,
            },{
                data: 'total',
                name: 'total',
            },{
                data: 'saldo',
                name: 'saldo',
            },{
                data: 'status',
                name: null,
                searchable: false,
                orderable: false,
            }
            // ,{
            //     data: 'action',
            //     name: 'action',
            //     orderable: false,
            //     searchable: false
            // }
        ]
        });
    }
    $('#btn-add-data').fireModal({
        title: "Tambah Pemasukan",
        body: '<?= Helper::includeAsJsString("pages.administrasi.pemasukan.form") ?>',
        buttons: [
            {
            text: '<i class="fas fa-plus-circle"></i> ',
            class: 'btn btn-success',
            handler: function(current_modal) {
                var html = '<?= Helper::includeAsJsString("pages.administrasi.pemasukan.input") ?>'
                current_modal.find('table').append(html);
                setNumeric();
            }
        },
        {
                submit: false,
                class: 'btn btn-primary',
                id: 'btn-submit',
                text: 'Simpan',
                handler: function(current_modal) {
                    saveForm($('#form-data'),_URL_INSERT,current_modal,1);
                }
        },
        {
            text: 'Close',
            class: 'btn btn-secondary',
            handler: function(current_modal) {
                $.destroyModal(current_modal);
                
            }
        }]
    });
    $('#btn-add-data').click(function(){
        setNumeric();
    })
    // Add event listener for opening and closing details
    function format(value) {
        // console.log();
            return value.detail;
        };
    $('#data tbody').on('click', 'td.dt-control', function () {
        var tr = $(this).closest('tr');
        var row = _TABLE.row(tr);
        
        if (row.child.isShown()) {
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('dt-hasChild shown');
        } else {
            // Open this row
            // console.log(row.data()[4]);
            row.child(format(row.data())).show();
            tr.addClass('dt-hasChild shown');
        }
    });
    $(document).on('click','.remove-input',function (e) { 
        e.preventDefault();
        $(this).closest('tr').remove();
    });
</script>

<script type="text/javascript" src="<?php echo e(asset('assets/js/save.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/delete.js')); ?>"></script>

<?php $__env->stopPush(); ?>


<?php echo $__env->make('app',['content'=>'user'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\administrasi\resources\views/pages/administrasi/pemasukan/index.blade.php ENDPATH**/ ?>