<?php
    use App\Traits\Helper;
?>
<table>
    <thead>
        <tr>
            <th>#</th>
            <th style="font-weight: bold">TANGGAL</th>
            <th style="font-weight: bold">NISN</th>
            <th style="font-weight: bold">NAMA SISWA</th>
            <th style="font-weight: bold">KELAS</th>
            <th style="font-weight: bold">DESKRIPSI</th>
            <th style="font-weight: bold">NOMINAL</th>
            <th style="font-weight: bold">TOTAL</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $no = 1;
            $number = 1;
            $i = 0;
            $tanggal = "";
            $nisn = "";
            $nama = "";
            $kelas = "";
            $tanggalConvert = "";
            
        ?>
        <?php $__currentLoopData = $htransaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total = 0; $totalConvert = 0;?>
        <?php $__currentLoopData = json_decode($val->{$tipe_tgg}); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php

                    if($no != $i){
                        $i = $no;
                        if($tanggal != date("d-m-Y",strtotime($val->created_at))){
                            $tanggal = date("d-m-Y",strtotime($val->created_at));
                             if($val->siswa != null){
                                $nisn = $val->siswa->nisn;
                                $nama = $val->siswa->nama;
                                $kelas = $val->siswa->kelas->nama." ".$val->siswa->kelas->jurusan->nama;
                            }else{
                                $nisn = '-';
                            }
                            $tanggalConvert = Helper::convertDate($val->created_at,false,false);
                            $totalConvert = $val->totalSum(date('Y-m-d',strtotime($val->tanggal)));
                            echo $number;
                            $number++;
                            
                        }else{
                            if($val->siswa != null){
                                $nisn = $val->siswa->nisn;
                                $nama = $val->siswa->nama;
                                $kelas = $val->siswa->kelas->nama." ".$val->siswa->kelas->jurusan->nama;
                            }else{
                                $nisn = '-';
                            }
                            $tanggalConvert = "";
                            $nama = "";
                            $nisn = "";
                        }
                        
                    }else{
                        $nama = "";
                        $nisn = "";
                        $tanggalConvert = "";
                    }
                ?>
            </td>
            <td><?php echo e($tanggalConvert); ?></td>
            <td style="text-align: left"><?php echo e($nisn); ?></td>
            <td><?php echo e($nama); ?></td>
            <td><?php echo e($kelas); ?></td>
            <td><?php echo e($key->nama_biaya); ?></td>
            <td style="text-align: right"><?php echo e(number_format($key->nominal,2,".",",")); ?></td>
            <td style="text-align: right">
                <?php 
                    if($totalConvert != $total){
                        $total = $totalConvert;
                        echo number_format($totalConvert,2,".",",");
                    }
                ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $no++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\xampp\htdocs\administrasi\resources\views/pages/report/htransaksi.blade.php ENDPATH**/ ?>