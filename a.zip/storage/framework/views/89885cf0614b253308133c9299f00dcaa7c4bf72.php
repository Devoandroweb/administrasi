
<?php echo $__env->make('vendor.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<?php 
use App\Traits\Helper;
?>
<section class="section">
    <div class="section-header">
    <h1>Detail Tunggakan</h1>
    
    <?php echo e(Breadcrumbs::render('administrasi_siswa_tunggakan')); ?>

    </div>

    <div class="section-body">
        <div class="card card-primary">
            <div class="card-header">
            <h4>Data Biaya tunggakan dengan Nama : <b class="text-success"><?php echo e($siswa->nama); ?></b> <i class="fas fa-angle-right"></i> Kelas : <b class="text-danger"><?php echo e($siswa->namaKelas()); ?></b> </h4>
            </div>
            <div class="card-body">
            <div class="table-responsive">
                <table id="data" class="table table-striped" width="100%">
                <thead>
                    <tr>
                    <th class="text-center" width="5%">
                        #
                    </th>
                    <th>Nama Biaya</th>
                    <th>Nominal</th>
                    <th>Tahun AJaran</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->nama_tunggakan); ?></td>
                            <td><?php echo ($item->nominal == 0) ? '<span class="text-success">Lunas</span>' : Helper::ribuan($item->nominal); ?></td>
                            <td><?php echo e($item->ajaran); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>
            </div>
        </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
$("#data").DataTable();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('app',['content'=>'user'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\administrasi\resources\views/pages/administrasi/siswa/tunggakan.blade.php ENDPATH**/ ?>