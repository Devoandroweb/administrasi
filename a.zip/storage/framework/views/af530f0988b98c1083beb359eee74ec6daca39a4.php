<?php use App\Models\MJurusan; ?>
<form action="" id="form-data">
    <div class="loader-line form-loader d-none"></div>
    <div class="form-group">
        <label>Nama Kelas</label>
        <input type="text" name="nama" class="form-control" required="" autocomplete="off">
    </div>
    <div class="form-group">
        <label for="exampleInputEmail1">Jurusan</label>
        <select id="role" class="form-control "
            name="id_jurusan" autocomplete="off">
            <option value="" selected disabled> Pilih Jurusan</option>
            <?php $__currentLoopData = MJurusan::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id_jurusan); ?>"><?php echo e($item->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</form>
<?php /**PATH D:\xampp\htdocs\administrasi\resources\views/pages/kelas/form.blade.php ENDPATH**/ ?>