
<?php echo $__env->make('vendor.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<?php 
use App\Traits\Helper;
?>
<section class="section">
    <div class="section-header">
    <h1>Cicilan Siswa</h1>
    
    <?php echo e(Breadcrumbs::render('administrasi_siswa_cicilan')); ?>

    </div>

    <div class="section-body">
        <div class="card card-primary">
            <div class="card-header">
            <h4>Data Cicilan Pembayaran dengan Nama : <b class="text-success"><?php echo e($siswa->nama); ?></b> <i class="fas fa-angle-right"></i> Kelas : <b class="text-danger"><?php echo e($siswa->namaKelas()); ?></b> </h4>
            </div>
        </div>
        
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#tab-ta-now" role="tab" aria-controls="tab-ta-now" aria-selected="true">TA <?php echo e(Session::get('tahun_awal')."/".Session::get('tahun_akhir')); ?></a>
            </li>
            <?php $__currentLoopData = $ajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
                <a class="nav-link " data-toggle="tab" href="#tab-ta-<?php echo e($aj->id); ?>" role="tab" aria-controls="tab-ta-<?php echo e($aj->id); ?>" aria-selected="false">TA <?php echo e($aj->tahun_awal."/".$aj->tahun_akhir); ?></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="tab-ta-now" role="tabpanel" aria-labelledby="tab-ta-now">
                <div class="row">
                    <?php $__currentLoopData = $adminsitrasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->cicilan->tipe == 1): ?>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="text-dark"><?php echo e($item->jenisAdministrasi->nama); ?></h4>
                                <div class="card-header-action">
                                    <a data-collapse="#adm-tab-<?php echo e($loop->iteration); ?>" class="btn btn-icon btn-danger" href="#"><i class="fas fa-plus"></i></a>
                                </div>
                            </div>
                            <div class="collapse" id="adm-tab-<?php echo e($loop->iteration); ?>">
                                <div class="card-body">
                                    <?php if($item->cicilan->deskripsi != null): ?>
                                    <table class="w-100">
                                        
                                        <?php
                                            $desc = json_decode($item->cicilan->deskripsi); 
                                        ?>
                                        <?php $__currentLoopData = $desc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $des): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                        <tr>
                                            <td>Cicilan <?php echo e($loop->iteration); ?></td>
                                            <td class="text-right"><?php echo e(Helper::ribuan($des)); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </table>
                                    <?php else: ?>
                                    <div class="text-danger w-100 text-center">
                                        Tidak ada Pembayaran
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php $__currentLoopData = $ajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="tab-pane fade" id="tab-ta-<?php echo e($aj->id); ?>" role="tabpanel" aria-labelledby="tab-ta-<?php echo e($aj->id); ?>">
                <div class="row">
                <?php $__currentLoopData = $tunggakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tgg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($aj->tahun_awal." - ".$aj->tahun_akhir == $tgg->ajaran): ?>
                        <?php if($tgg->cicilan->tipe == 2): ?>
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="text-dark"><?php echo e($tgg->nama_tunggakan); ?></h4>
                                        <div class="card-header-action">
                                            <a data-collapse="#tgg-tab-<?php echo e($loop->iteration); ?>" class="btn btn-icon btn-danger" href="#"><i class="fas fa-plus"></i></a>
                                        </div>
                                    </div>
                                    <div class="collapse" id="tgg-tab-<?php echo e($loop->iteration); ?>">
                                        <div class="card-body">
                                            <?php if($tgg->cicilan->deskripsi != null): ?>
                                            <table class="w-100">
                                                
                                                <?php
                                                    $desc = json_decode($tgg->cicilan->deskripsi); 
                                                ?>
                                                <?php $__currentLoopData = $desc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $des): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                                <tr>
                                                    <td>Cicilan <?php echo e($loop->iteration); ?></td>
                                                    <td class="text-right"><?php echo e(Helper::ribuan($des)); ?></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                            </table>
                                            <?php else: ?>
                                            <div class="text-danger w-100 text-center">
                                                Tidak ada Pembayaran
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('app',['content'=>'user'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\administrasi\resources\views/pages/administrasi/siswa/cicilan.blade.php ENDPATH**/ ?>