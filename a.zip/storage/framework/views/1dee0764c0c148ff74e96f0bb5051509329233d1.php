<?php
    function menuActive($url){
      if(url()->current() == $url){
        return 'active';
      }
    }
    function menuActiveDropdown($index){
      $url[] = [
          url('jenis-administrasi'),
          url('jurusan'),
          url('kelas'),
          url('ajaran'),
          url('siswa')
      ];
      $url[] = [
          url('administrasi-siswa'),
          url('pendanaan')
      ];
      $url[] = [
          url('rekap/per-kelas'),
          url('rekap/per-siswa')
      ];
      if(in_array(url()->current(),$url[$index])){
        return 'active';
      }
    }
?>
<div class="main-sidebar sidebar-style-2" style="padding-bottom: 2rem;">
  <aside id="sidebar-wrapper">
    <div class="sidebar-brand">
      <a href="<?php echo e(url('dashboard')); ?>">
        <img src="<?php echo e(asset('assets/img/logo_sekolah.png')); ?>" class="mr-1 mt-3" width="15%" alt=""> <br> 
        SIA SMAI AL-HIKMAH
      </a>
    </div>
    <div class="sidebar-brand sidebar-brand-sm">
      <img src="<?php echo e(asset('assets/img/logo_sekolah.png')); ?>" class="mr-1 mt-3" width="50%" alt=""> <br>
    </div>
    <hr>
    <ul class="sidebar-menu">
        
          <?php if(auth()->guard('siswa')->check()): ?>
          <li class="<?php echo e(menuActive(url('client/dashboard'))); ?>"><a href="<?php echo e(url('client/dashboard')); ?>" class="nav-link"><i class="fas fa-fire"></i><span>Dashboard</span></a></li>
          <li class="<?php echo e(menuActive(url('client/profile'))); ?>"><a href="<?php echo e(url('client/profile')); ?>" class="nav-link"><i class="fas fa-user"></i><span>Profile</span></a></li>
          <li class="<?php echo e(menuActive(url('client/cetak-administrasi'))); ?>"><a href="<?php echo e(url('client/cetak-administrasi')); ?>" class="nav-link"><i class="fas fa-print"></i><span>Cetak Administrasi</span></a></li>
          <?php endif; ?>

          <?php if(auth()->guard('web')->check()): ?>
          <li class="<?php echo e(menuActive(url('dashboard'))); ?>"><a href="<?php echo e(url('dashboard')); ?>" class="nav-link"><i class="fas fa-fire"></i><span>Dashboard</span></a></li>
          <?php if(auth()->guard('web')->user()->role == 3): ?>
          <li class="<?php echo e(menuActive(url('siswa'))); ?>"><a href="<?php echo e(url('siswa')); ?>" class="nav-link"><i class="fas fa-user-graduate"></i><span>Siswa</span></a></li>
          <?php else: ?>
          <li class="menu-header">Menu Utama</li>
          <li class="nav-item dropdown <?php echo e(menuActiveDropdown(0)); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-brain"></i> <span>Master</span></a>
            <ul class="dropdown-menu">
              <li><a class="nav-link" href="<?php echo e(url('jenis-administrasi')); ?>">Jenis Administrasi</a></li>
              <li><a class="nav-link" href="<?php echo e(url('jurusan')); ?>">Data Jurusan</a></li>
              <li><a class="nav-link" href="<?php echo e(url('kelas')); ?>">Data Kelas</a></li>
              <li><a class="nav-link" href="<?php echo e(url('ajaran')); ?>">Data Ajaran</a></li>
              <li><a class="nav-link" href="<?php echo e(url('siswa')); ?>">Data Siswa</a></li>
            </ul>
          </li>
          <?php endif; ?>
          <li class="nav-item dropdown <?php echo e(menuActiveDropdown(1)); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-coins"></i> <span>Administrasi</span></a>
            <ul class="dropdown-menu">
              <li><a class="nav-link" href="<?php echo e(url('administrasi-siswa')); ?>">Siswa</a></li>
              <li><a class="nav-link" href="<?php echo e(url('pendanaan')); ?>">Pendanaan</a></li>
            </ul>
          </li>
          <li class="menu-header">Laporan</li>
          <li class="nav-item dropdown <?php echo e(menuActiveDropdown(2)); ?>">
            <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-book"></i> <span>Rekap</span></a>
            <ul class="dropdown-menu">
              <li><a class="nav-link" href="<?php echo e(url('rekap/per-kelas')); ?>">Per-Kelas</a></li>
              <li><a class="nav-link" href="<?php echo e(url('rekap/per-siswa')); ?>">Per-Siswa</a></li>
            </ul>
          </li>
          <li class="<?php echo e(menuActive(url('htransaksi'))); ?>"><a class="nav-link" href="<?php echo e(url('htransaksi')); ?>"><i class="fas fa-clock"></i> <span>Riwayat Transaksi</span></a></li>
          <li class="<?php echo e(menuActive(url('laporan'))); ?>"><a class="nav-link" href="<?php echo e(url('laporan')); ?>"><i class="fas fa-print"></i> <span>Report</span></a></li>

          <?php if(auth()->guard('web')->user()->role != 3): ?>
          <li class="menu-header">Lainnya</li>
          <li class="<?php echo e(menuActive(url('whatsapp'))); ?>"><a class="nav-link" href="<?php echo e(url('whatsapp')); ?>"><i class="fab fa-whatsapp"></i> <span>WA Gateway</span></a></li>
          <li class="<?php echo e(menuActive(url('user'))); ?>"><a class="nav-link" href="<?php echo e(url('user')); ?>"><i class="fas fa-user-astronaut"></i> <span>User Management</span></a></li>
          <?php endif; ?>
        <?php endif; ?>
    </ul>
    
  </aside>
</div><?php /**PATH D:\xampp\htdocs\administrasi\resources\views/panels/sidebar.blade.php ENDPATH**/ ?>