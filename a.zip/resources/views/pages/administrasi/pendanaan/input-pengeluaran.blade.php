<tr class="add-input">
    <td>
        <div class="form-group  mb-0">
            <input type="text" name="nama_pengeluaran[]" class="form-control" required="" autocomplete="off">
        </div>
    </td>
    <td width="5%" class="text-center"><i class="fas fa-caret-left"></i> <i class="fas fa-caret-right"></i></td>
    <td >
        <div class="form-group d-flex mb-0">
            <input type="text" name="nominal[]" class="form-control mr-2 numeric" required="" autocomplete="off">
            <button class="btn btn-danger remove-input"><i class="fas fa-trash"></i></button>
        </div>
    </td>
</tr>