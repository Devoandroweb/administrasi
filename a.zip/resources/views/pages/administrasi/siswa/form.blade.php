<form action="" id="form-data">
    <div class="form-group">
        <label>Nama Jurusan</label>
        <input type="text" name="nama" class="form-control" required="" autocomplete="off">
    </div>
</form>
