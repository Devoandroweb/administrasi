<form action="" id="form-data">
    <div class="form-group">
        <label>Nama Administrasi</label>
        <input type="text" name="nama" class="form-control text-uppercase" required="" autocomplete="off">
    </div>
    <div class="form-group">
        <label>Nominal</label>
        <input type="text" name="biaya" class="form-control numeric" required="" autocomplete="off">
    </div>
</form>
