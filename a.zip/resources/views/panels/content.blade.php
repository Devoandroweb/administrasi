<!-- Main Content -->
      <div class="main-content">
        @yield('content')
      </div>