<footer class="main-footer">
  <div class="footer-left">
    Copyright &copy; 2022 <div class="bullet"></div> Developer By <a href="https://wa.me/+6281803319221" target="_blank">M. Fathur Rosidin (<i class="fab fa-whatsapp"></i> +6281803319221 )</a>
  </div>
  <div class="footer-right">
    1.0.0
  </div>
</footer>